export const DynamicFilter=(data,filterBy)=>{
   return data.filter(o =>{
        return Object.keys(filterBy).every(k => filterBy[k].some(f => o[k] === f))});
}

