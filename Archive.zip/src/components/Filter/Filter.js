import React,{Component} from 'react';
import './Filter.css'

class Filter extends Component {
    constructor(props) {
        super(props)
        
    }

    render(){
    
        const {nameHandler,name,title,field,filedHandler,titleHandler,dateHandler,date,filterHandler} = this.props
        return(
          <div className="layout">
                <input type="text" id="name" name="name" placeholder="name" value={name} onChange = {nameHandler} />
                <input type="date" id="changeDate" name="changeDate" placeholder="change date" value ={date} onChange ={dateHandler} />
                <input type="text" id="title" name="title" placeholder="title" value={title} onChange = {titleHandler} />
                <input type="text" id="field" name="field" placeholder="field" value={field} onChange = {filedHandler} />
                <button onClick={filterHandler}>Submit</button>
          </div>
        )
    }
}
export default Filter