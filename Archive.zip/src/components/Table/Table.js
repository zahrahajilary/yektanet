import React, { Component } from 'react';
import { SORT } from '../../utils/sort';
import Pagination from '../Pagination/Pagination';
import { SetParamUrl, GetParamUrl } from '../../utils/urlHanlder';
import { DynamicFilter } from '../../utils/Filter'
import Filter from '../Filter/Filter'
import './Table.css'

class Table extends Component {
    constructor(props) {
        super(props)
        this.state = {
            body: [],
            sorted: null,
            name: '',
            date: '',
            title: '',
            field: '',
            BST: undefined
        }
    }
    componentWillMount() {
        const { BST } = this.props
        let data = BST.root.children
        let date = BST.root.value
        date = (new Date(date)).toISOString().split('T')[0];
        this.setState({
            body: data,
            date: date,
            BST: BST
        })
        if (window.location.search.length > 1) {
            const sorted = GetParamUrl('sortedBy')
            this.setState({
                sorted: sorted,
            }, () => {
                this.renderFromUrl(this.state.body)
            })
        }

    }

    sortItem = (body, item) => {
        const listItem = SORT(body, item)
        this.setState({
            body: listItem,
            sorted: item
        }, () => {
            SetParamUrl('sortedBy', this.state.sorted)
        })

    }
    renderHeaderTable = () => {
        const { header } = this.props;
        let tableHeader = header &&
            header.map((item, index) => <th key={index} onClick={() => this.sortItem(this.state.body, item.key)}>{item.value}</th>)
        return tableHeader;
    }

    renderFromUrl = (body) => {
        if (this.state.body.length > 1 && window.location.search.length > 1) {
            this.sortItem(body, this.state.sorted)
        }
    }

    onChangePage = (pageOfItems) => {
        // update state with new page of items
        this.setState({ body: pageOfItems }, () => {
            if (window.location.search.length > 1) {
                this.sortItem(this.state.body, this.state.sorted)
            }

        });
    }
    submitFilterHandler = () => {
        let newBody = this.state.BST.find(this.state.date)
        let filterItem = {}
        let filterData = []
        this.setState({body: newBody.children}, () => {
          this.state.name.trim().length > 1 && Object.assign(filterItem, { name: [this.state.name] });
          this.state.title.trim().length > 1 && Object.assign(filterItem, { title: [this.state.title] });
          this.state.field.trim().length > 1 && Object.assign(filterItem, { field: [this.state.filterData] });
          filterData = DynamicFilter(this.state.body, filterItem)
          this.setState({
              body:filterData
          })     
        })
    }
    renderTableData = () => {
        let items = []
        if (this.state.body && this.state.body.length > 0) {
            items = this.state.body
        }
        return items.map((item) => {

            const { id, name, date, title, field, old_value, new_value } = item
            return (
                <>
                    <tr key={id}>
                        <td>{name}</td>
                        <td>{date}</td>
                        <td>{title}</td>
                        <td>{field}</td>
                        <td>{old_value}</td>
                        <td>{new_value}</td>
                    </tr>
                </>
            )
        })


    }
    nameHandler = (event) => {
        this.setState({
            name: event.target.value
        })
    }
    renderFilter = () => {
        return (
            <>
                <Filter
                    name={this.state.name}
                    nameHandler={(event) => this.setState({ name: event.target.value })}
                    field={this.state.field}
                    filedHandler={(event) => this.setState({ field: event.target.value })}
                    date={this.state.date}
                    dateHandler={(event) => this.dateHandler(event)}
                    title={this.state.title}
                    titleHandler={(event) => this.setState({ title: event.target.value })}
                    filterHandler={() => this.submitFilterHandler()}
                />
            </>
        )
    }
    dateHandler = (event) => {
        this.setState({ date: event.target.value }, () => {

            let resultDate = this.state.BST.find(this.state.date)
            this.setState({
                body: resultDate.children
            })
        })
    }
    render() {
        return (
            <div>
                {this.renderFilter()}
                <table id="table-1">
                    <tbody>
                        <tr>{this.renderHeaderTable()}</tr>
                        {this.renderTableData()}
                    </tbody>
                </table>
            </div>
        )
    }
}

export default Table